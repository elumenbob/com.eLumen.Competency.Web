# IO.Swagger.Model.InlineResponse401ImsxCodeMinor
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ImsxCodeMinorField** | [**List&lt;InlineResponse401ImsxCodeMinorImsxCodeMinorField&gt;**](InlineResponse401ImsxCodeMinorImsxCodeMinorField.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

