# IO.Swagger.Api.DocumentsManagerApi

All URIs are relative to *http://www.imsglobal.org/ims/case/v1p0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetAllCFDocuments**](DocumentsManagerApi.md#getallcfdocuments) | **GET** /CFDocuments | The REST read request message for the getAllCFDocuments() API call.
[**GetCFDocument**](DocumentsManagerApi.md#getcfdocument) | **GET** /CFDocuments/{sourcedId} | The REST read request message for the getCFDocument() API call.


<a name="getallcfdocuments"></a>
# **GetAllCFDocuments**
> InlineResponse200 GetAllCFDocuments (int? limit = null, int? offset = null, string sort = null, string orderBy = null, string filter = null, List<string> fields = null)

The REST read request message for the getAllCFDocuments() API call.

This is a request to the Service Provider to provide all of the Competency Framework Documents. 

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetAllCFDocumentsExample
    {
        public void main()
        {
            
            var apiInstance = new DocumentsManagerApi();
            var limit = 56;  // int? | This is used as part of the data pagination mechanism to control the download rate of data. The 'limit' defines the download segmentation value i.e. the maximum number of records to be contained in the response. The form of implementation is described in the corresponding binding document(s). (optional)  (default to 100)
            var offset = 56;  // int? | This is used as part of the data pagination mechanism to control the download rate of data. The 'offset' is the number of the first record to be supplied in the segmented response message. The form of implementation is described in the corresponding binding document(s). (optional)  (default to 0)
            var sort = sort_example;  // string | This is used as part of the sorting mechanism to be use by the service provider. The 'sort' identifies the sort criteria to be used for the records in the response message. Use with the orderBy parameter. The form of implementation is described in the corresponding binding document(s). (optional) 
            var orderBy = orderBy_example;  // string | This is used as part of the sorting mechanism to be use by the service provider. This defines the form of ordering for response to the sorted request i.e. ascending (asc) or descending (desc). The form of implementation is described in the corresponding binding document(s). (optional) 
            var filter = filter_example;  // string | This is used for the data filtering mechanism to be applied by the service provider. It defines the filtering rules to be applied when identifying the records to be supplied in the response message. The form of implementation is described in the corresponding binding document(s). (optional) 
            var fields = new List<string>(); // List<string> | This is used as part of the field selection mechanism to be applied by the service provider. This identifies the range of fields that should be supplied in the response message. The form of implementation is described in the corresponding binding document(s). (optional) 

            try
            {
                // The REST read request message for the getAllCFDocuments() API call.
                InlineResponse200 result = apiInstance.GetAllCFDocuments(limit, offset, sort, orderBy, filter, fields);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DocumentsManagerApi.GetAllCFDocuments: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int?**| This is used as part of the data pagination mechanism to control the download rate of data. The &#39;limit&#39; defines the download segmentation value i.e. the maximum number of records to be contained in the response. The form of implementation is described in the corresponding binding document(s). | [optional] [default to 100]
 **offset** | **int?**| This is used as part of the data pagination mechanism to control the download rate of data. The &#39;offset&#39; is the number of the first record to be supplied in the segmented response message. The form of implementation is described in the corresponding binding document(s). | [optional] [default to 0]
 **sort** | **string**| This is used as part of the sorting mechanism to be use by the service provider. The &#39;sort&#39; identifies the sort criteria to be used for the records in the response message. Use with the orderBy parameter. The form of implementation is described in the corresponding binding document(s). | [optional] 
 **orderBy** | **string**| This is used as part of the sorting mechanism to be use by the service provider. This defines the form of ordering for response to the sorted request i.e. ascending (asc) or descending (desc). The form of implementation is described in the corresponding binding document(s). | [optional] 
 **filter** | **string**| This is used for the data filtering mechanism to be applied by the service provider. It defines the filtering rules to be applied when identifying the records to be supplied in the response message. The form of implementation is described in the corresponding binding document(s). | [optional] 
 **fields** | [**List&lt;string&gt;**](string.md)| This is used as part of the field selection mechanism to be applied by the service provider. This identifies the range of fields that should be supplied in the response message. The form of implementation is described in the corresponding binding document(s). | [optional] 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcfdocument"></a>
# **GetCFDocument**
> InlineResponse200 GetCFDocument (string sourcedId)

The REST read request message for the getCFDocument() API call.

This is a request to the service provider to provide the information for the specific Competency Framework Document. If the identified record cannot be found then the 'unknownobject' status code must be reported.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCFDocumentExample
    {
        public void main()
        {
            
            var apiInstance = new DocumentsManagerApi();
            var sourcedId = sourcedId_example;  // string | The GUID that identifies the Competency Framework Document that is to be read from the service provider.

            try
            {
                // The REST read request message for the getCFDocument() API call.
                InlineResponse200 result = apiInstance.GetCFDocument(sourcedId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DocumentsManagerApi.GetCFDocument: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sourcedId** | **string**| The GUID that identifies the Competency Framework Document that is to be read from the service provider. | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

