# IO.Swagger.Model.CFPackageType
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CFDocument** | [**CFDocumentSetTypeCFDocuments**](CFDocumentSetTypeCFDocuments.md) |  | [optional] 
**CFItems** | [**List&lt;CFPackageTypeCFItems&gt;**](CFPackageTypeCFItems.md) |  | [optional] 
**CFAssociations** | [**List&lt;CFAssociationSetTypeCFAssociations&gt;**](CFAssociationSetTypeCFAssociations.md) |  | [optional] 
**CFDefinitions** | [**CFPackageTypeCFDefinitions**](CFPackageTypeCFDefinitions.md) |  | [optional] 
**CFRubrics** | [**List&lt;CFPackageTypeCFRubrics&gt;**](CFPackageTypeCFRubrics.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

