# IO.Swagger.Api.RubricsManagerApi

All URIs are relative to *http://www.imsglobal.org/ims/case/v1p0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetCFRubric**](RubricsManagerApi.md#getcfrubric) | **GET** /CFRubrics/{sourcedId} | The REST read request message for the getCFRubric() API call.


<a name="getcfrubric"></a>
# **GetCFRubric**
> InlineResponse200 GetCFRubric (string sourcedId)

The REST read request message for the getCFRubric() API call.

This is a request to the service provider to provide the information for the specific Competency Framework Rubric. If the identified record cannot be found then the 'unknownobject' status code must be reported.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCFRubricExample
    {
        public void main()
        {
            
            var apiInstance = new RubricsManagerApi();
            var sourcedId = sourcedId_example;  // string | The GUID that identifies the Competency Framework Rubric that is to be read from the service provider.

            try
            {
                // The REST read request message for the getCFRubric() API call.
                InlineResponse200 result = apiInstance.GetCFRubric(sourcedId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling RubricsManagerApi.GetCFRubric: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sourcedId** | **string**| The GUID that identifies the Competency Framework Rubric that is to be read from the service provider. | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

