# IO.Swagger.Model.CFSubjectType
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Identifier** | **string** | The data-type for establishing a Globally Unique Identifier (GUID). The form of the GUID is a Universally Unique Identifier (UUID) of 16 hexadecimal characters (lower case) in the format 8-4-4-4-12. | 
**Uri** | **string** | Model Primitive Datatype &#x3D; AnyURI | 
**Title** | **string** | Model Primitive Datatype &#x3D; NormalizedString | 
**HierarchyCode** | **string** | Model Primitive Datatype &#x3D; NormalizedString | 
**Description** | **string** | Model Primitive Datatype &#x3D; String | [optional] 
**LastChangeDateTime** | **DateTime?** | Model Primitive Datatype &#x3D; DateTime | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

