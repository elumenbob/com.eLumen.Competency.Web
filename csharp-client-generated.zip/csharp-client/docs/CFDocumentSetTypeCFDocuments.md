# IO.Swagger.Model.CFDocumentSetTypeCFDocuments
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Identifier** | **string** | The data-type for establishing a Globally Unique Identifier (GUID). The form of the GUID is a Universally Unique Identifier (UUID) of 16 hexadecimal characters (lower case) in the format 8-4-4-4-12. | 
**Uri** | **string** | Model Primitive Datatype &#x3D; AnyURI | 
**Creator** | **string** | Model Primitive Datatype &#x3D; NormalizedString | 
**Title** | **string** | Model Primitive Datatype &#x3D; NormalizedString | 
**LastChangeDateTime** | **DateTime?** | Model Primitive Datatype &#x3D; DateTime | 
**OfficialSourceURL** | **string** | The data-type for establishing a Uniform Resource Locator (URL) as defined by W3C. | [optional] 
**Publisher** | **string** | Model Primitive Datatype &#x3D; NormalizedString | [optional] 
**Description** | **string** | Model Primitive Datatype &#x3D; NormalizedString | [optional] 
**Subject** | **List&lt;string&gt;** | Model Primitive Datatype &#x3D; NormalizedString | [optional] 
**SubjectURI** | [**CFAssociationTypeOriginNodeURI**](CFAssociationTypeOriginNodeURI.md) |  | [optional] 
**Language** | **string** | Model Primitive Datatype &#x3D; Language | [optional] 
**Version** | **string** | Model Primitive Datatype &#x3D; NormalizedString | [optional] 
**AdoptionStatus** | **string** | Model Primitive Datatype &#x3D; NormalizedString | [optional] 
**StatusStartDate** | **DateTime?** | Model Primitive Datatype &#x3D; Date | [optional] 
**StatusEndDate** | **DateTime?** | Model Primitive Datatype &#x3D; Date | [optional] 
**LicenseURI** | [**CFAssociationTypeOriginNodeURI**](CFAssociationTypeOriginNodeURI.md) |  | [optional] 
**Notes** | **string** | Model Primitive Datatype &#x3D; String | [optional] 
**CFPackageURI** | **string** | Model Primitive Datatype &#x3D; AnyURI | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

