# IO.Swagger.Model.CFPackageTypeCFRubricCriteria
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Identifier** | **string** | The data-type for establishing a Globally Unique Identifier (GUID). The form of the GUID is a Universally Unique Identifier (UUID) of 16 hexadecimal characters (lower case) in the format 8-4-4-4-12. | 
**Uri** | **string** | Model Primitive Datatype &#x3D; AnyURI | [optional] 
**Category** | **string** | Model Primitive Datatype &#x3D; NormalizedString | [optional] 
**Description** | **string** | Model Primitive Datatype &#x3D; String | [optional] 
**CFItemURI** | **string** | Model Primitive Datatype &#x3D; AnyURI | [optional] 
**Weight** | **float?** | Model Primitive Datatype &#x3D; Float | [optional] 
**Position** | **int?** | Model Primitive Datatype &#x3D; Integer | [optional] 
**RubricId** | **string** | The data-type for establishing a Globally Unique Identifier (GUID). The form of the GUID is a Universally Unique Identifier (UUID) of 16 hexadecimal characters (lower case) in the format 8-4-4-4-12. | [optional] 
**LastChangeDateTime** | **DateTime?** | Model Primitive Datatype &#x3D; DateTime | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

