# IO.Swagger.Model.CFAssociationSetTypeCFAssociations
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Identifier** | **string** | The data-type for establishing a Globally Unique Identifier (GUID). The form of the GUID is a Universally Unique Identifier (UUID) of 16 hexadecimal characters (lower case) in the format 8-4-4-4-12. | 
**AssociationType** | **string** |  | 
**CFDocumentURI** | **string** | Model Primitive Datatype &#x3D; AnyURI | [optional] 
**OriginNodeIdentifier** | **string** | The data-type for establishing a Globally Unique Identifier (GUID). The form of the GUID is a Universally Unique Identifier (UUID) of 16 hexadecimal characters (lower case) in the format 8-4-4-4-12. | 
**DestinationNodeIdentifier** | **string** | The data-type for establishing a Globally Unique Identifier (GUID). The form of the GUID is a Universally Unique Identifier (UUID) of 16 hexadecimal characters (lower case) in the format 8-4-4-4-12. | 
**SequenceNumber** | **int?** | Model Primitive Datatype &#x3D; Integer | [optional] 
**Uri** | **string** | Model Primitive Datatype &#x3D; AnyURI | 
**OriginNodeURI** | [**CFAssociationTypeOriginNodeURI**](CFAssociationTypeOriginNodeURI.md) |  | [optional] 
**DestinationNodeURI** | [**CFAssociationTypeOriginNodeURI**](CFAssociationTypeOriginNodeURI.md) |  | [optional] 
**CFAssociationGroupingIdentifier** | **string** | The data-type for establishing a Globally Unique Identifier (GUID). The form of the GUID is a Universally Unique Identifier (UUID) of 16 hexadecimal characters (lower case) in the format 8-4-4-4-12. | [optional] 
**CFAssociationGroupingURI** | [**CFAssociationTypeOriginNodeURI**](CFAssociationTypeOriginNodeURI.md) |  | [optional] 
**LastChangeDateTime** | **DateTime?** | Model Primitive Datatype &#x3D; DateTime | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

