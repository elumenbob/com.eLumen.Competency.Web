# IO.Swagger.Model.CFAssociationSetType
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CFAssociations** | [**List&lt;CFAssociationSetTypeCFAssociations&gt;**](CFAssociationSetTypeCFAssociations.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

