# IO.Swagger.Model.CFDefinitionType
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CFConcepts** | [**List&lt;CFDefinitionTypeCFConcepts&gt;**](CFDefinitionTypeCFConcepts.md) |  | [optional] 
**CFSubjects** | [**List&lt;CFDefinitionTypeCFSubjects&gt;**](CFDefinitionTypeCFSubjects.md) |  | [optional] 
**CFLicenses** | [**List&lt;CFDefinitionTypeCFLicenses&gt;**](CFDefinitionTypeCFLicenses.md) |  | [optional] 
**CFItemTypes** | [**List&lt;CFDefinitionTypeCFItemTypes&gt;**](CFDefinitionTypeCFItemTypes.md) |  | [optional] 
**CFAssociationGroupings** | [**List&lt;InlineResponse200&gt;**](InlineResponse200.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

