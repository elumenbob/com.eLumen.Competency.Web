# IO.Swagger.Model.CFPackageTypeCFItems
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Identifier** | **string** | The data-type for establishing a Globally Unique Identifier (GUID). The form of the GUID is a Universally Unique Identifier (UUID) of 16 hexadecimal characters (lower case) in the format 8-4-4-4-12. | 
**CFDocumentURI** | **string** | Model Primitive Datatype &#x3D; AnyURI | 
**FullStatement** | **string** | Model Primitive Datatype &#x3D; NormalizedString | 
**AlternativeLabel** | **string** | Model Primitive Datatype &#x3D; NormalizedString | [optional] 
**CFItemType** | **string** | Model Primitive Datatype &#x3D; NormalizedString | [optional] 
**Uri** | **string** | Model Primitive Datatype &#x3D; AnyURI | 
**HumanCodingScheme** | **string** | Model Primitive Datatype &#x3D; NormalizedString | [optional] 
**ListEnumeration** | **string** | Model Primitive Datatype &#x3D; NormalizedString | [optional] 
**AbbreviatedStatement** | **string** | Model Primitive Datatype &#x3D; NormalizedString | [optional] 
**ConceptKeywords** | **List&lt;string&gt;** | Model Primitive Datatype &#x3D; NormalizedString | [optional] 
**ConceptKeywordsURI** | [**CFAssociationTypeOriginNodeURI**](CFAssociationTypeOriginNodeURI.md) |  | [optional] 
**Notes** | **string** | Model Primitive Datatype &#x3D; String | [optional] 
**Language** | **string** | Model Primitive Datatype &#x3D; Language | [optional] 
**EducationLevel** | **List&lt;string&gt;** | Model Primitive Datatype &#x3D; NormalizedString | [optional] 
**CFItemTypeURI** | [**CFAssociationTypeOriginNodeURI**](CFAssociationTypeOriginNodeURI.md) |  | [optional] 
**License** | **string** | Model Primitive Datatype &#x3D; NormalizedString | [optional] 
**LicenseURI** | [**CFAssociationTypeOriginNodeURI**](CFAssociationTypeOriginNodeURI.md) |  | [optional] 
**StatusStartDate** | **DateTime?** | Model Primitive Datatype &#x3D; Date | [optional] 
**StatusEndDate** | **DateTime?** | Model Primitive Datatype &#x3D; Date | [optional] 
**LastChangeDateTime** | **DateTime?** | Model Primitive Datatype &#x3D; DateTime | 
**CFItemAssociationURI** | **string** | Model Primitive Datatype &#x3D; AnyURI | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

