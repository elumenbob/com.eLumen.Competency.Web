# IO.Swagger.Api.AssociationsManagerApi

All URIs are relative to *http://www.imsglobal.org/ims/case/v1p0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetCFItemAssociations**](AssociationsManagerApi.md#getcfitemassociations) | **GET** /CFItemAssociations/{sourcedId} | The REST read request message for the getCFItemAssociations() API call.


<a name="getcfitemassociations"></a>
# **GetCFItemAssociations**
> InlineResponse200 GetCFItemAssociations (string sourcedId)

The REST read request message for the getCFItemAssociations() API call.

This is a request to the Service Provider to provide the all of the Competency Associations for the specified CFItem.  If the identified record cannot be found then the 'unknownobject' status code must be reported.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCFItemAssociationsExample
    {
        public void main()
        {
            
            var apiInstance = new AssociationsManagerApi();
            var sourcedId = sourcedId_example;  // string | The GUID that identifies the CFItem for which ALL associations are to be supplied.

            try
            {
                // The REST read request message for the getCFItemAssociations() API call.
                InlineResponse200 result = apiInstance.GetCFItemAssociations(sourcedId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling AssociationsManagerApi.GetCFItemAssociations: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sourcedId** | **string**| The GUID that identifies the CFItem for which ALL associations are to be supplied. | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

