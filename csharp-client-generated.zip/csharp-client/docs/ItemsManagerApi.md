# IO.Swagger.Api.ItemsManagerApi

All URIs are relative to *http://www.imsglobal.org/ims/case/v1p0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetCFItem**](ItemsManagerApi.md#getcfitem) | **GET** /CFItems/{sourcedId} | The REST read request message for the getCFItem() API call.


<a name="getcfitem"></a>
# **GetCFItem**
> InlineResponse200 GetCFItem (string sourcedId)

The REST read request message for the getCFItem() API call.

This is a request to the Service Provider to provide the specified Competency Framework Item.  If the identified record cannot be found then the 'unknownobject' status code must be reported.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCFItemExample
    {
        public void main()
        {
            
            var apiInstance = new ItemsManagerApi();
            var sourcedId = sourcedId_example;  // string | The GUID that identifies the Competency Framework Item that is to be read from the service provider.

            try
            {
                // The REST read request message for the getCFItem() API call.
                InlineResponse200 result = apiInstance.GetCFItem(sourcedId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling ItemsManagerApi.GetCFItem: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sourcedId** | **string**| The GUID that identifies the Competency Framework Item that is to be read from the service provider. | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

