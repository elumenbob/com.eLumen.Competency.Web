# IO.Swagger.Api.DefinitionsManagerApi

All URIs are relative to *http://www.imsglobal.org/ims/case/v1p0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetCFAssociationGrouping**](DefinitionsManagerApi.md#getcfassociationgrouping) | **GET** /CFAssociationGroupings/{sourcedId} | The REST read request message for the getCFAssociationGrouping() API call.
[**GetCFConcept**](DefinitionsManagerApi.md#getcfconcept) | **GET** /CFConcepts/{sourcedId} | The REST read request message for the getCFConcept() API call.
[**GetCFItemType**](DefinitionsManagerApi.md#getcfitemtype) | **GET** /CFItemTypes/{sourcedId} | The REST read request message for the getCFItemType() API call.
[**GetCFLicense**](DefinitionsManagerApi.md#getcflicense) | **GET** /CFLicenses/{sourcedId} | The REST read request message for the getCFLicense() API call.
[**GetCFSubject**](DefinitionsManagerApi.md#getcfsubject) | **GET** /CFSubjects/{sourcedId} | The REST read request message for the getCFSubject() API call.


<a name="getcfassociationgrouping"></a>
# **GetCFAssociationGrouping**
> InlineResponse200 GetCFAssociationGrouping (string sourcedId)

The REST read request message for the getCFAssociationGrouping() API call.

This is a request to the Service Provider to provide the specified Competency Framework Association Grouping.  If the identified record cannot be found then the 'unknownobject' status code must be reported.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCFAssociationGroupingExample
    {
        public void main()
        {
            
            var apiInstance = new DefinitionsManagerApi();
            var sourcedId = sourcedId_example;  // string | The GUID that identifies the Competency Framework AssociationGrouping that is to be read from the service provider.

            try
            {
                // The REST read request message for the getCFAssociationGrouping() API call.
                InlineResponse200 result = apiInstance.GetCFAssociationGrouping(sourcedId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefinitionsManagerApi.GetCFAssociationGrouping: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sourcedId** | **string**| The GUID that identifies the Competency Framework AssociationGrouping that is to be read from the service provider. | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcfconcept"></a>
# **GetCFConcept**
> InlineResponse200 GetCFConcept (string sourcedId)

The REST read request message for the getCFConcept() API call.

This is a request to the Service Provider to provide the specified Competency Framework Concept.  If the identified record cannot be found then the 'unknownobject' status code must be reported.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCFConceptExample
    {
        public void main()
        {
            
            var apiInstance = new DefinitionsManagerApi();
            var sourcedId = sourcedId_example;  // string | The GUID that identifies the Competency Framework Concept that is to be read from the service provider.

            try
            {
                // The REST read request message for the getCFConcept() API call.
                InlineResponse200 result = apiInstance.GetCFConcept(sourcedId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefinitionsManagerApi.GetCFConcept: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sourcedId** | **string**| The GUID that identifies the Competency Framework Concept that is to be read from the service provider. | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcfitemtype"></a>
# **GetCFItemType**
> InlineResponse200 GetCFItemType (string sourcedId)

The REST read request message for the getCFItemType() API call.

This is a request to the Service Provider to provide the specified Competency Framework Item Type.  If the identified record cannot be found then the 'unknownobject' status code must be reported.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCFItemTypeExample
    {
        public void main()
        {
            
            var apiInstance = new DefinitionsManagerApi();
            var sourcedId = sourcedId_example;  // string | The GUID that identifies the Competency Framework ItemType that is to be read from the service provider.

            try
            {
                // The REST read request message for the getCFItemType() API call.
                InlineResponse200 result = apiInstance.GetCFItemType(sourcedId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefinitionsManagerApi.GetCFItemType: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sourcedId** | **string**| The GUID that identifies the Competency Framework ItemType that is to be read from the service provider. | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcflicense"></a>
# **GetCFLicense**
> InlineResponse200 GetCFLicense (string sourcedId)

The REST read request message for the getCFLicense() API call.

This is a request to the Service Provider to provide the specified Competency Framework License.  If the identified record cannot be found then the 'unknownobject' status code must be reported.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCFLicenseExample
    {
        public void main()
        {
            
            var apiInstance = new DefinitionsManagerApi();
            var sourcedId = sourcedId_example;  // string | The GUID that identifies the Competency Framework License that is to be read from the service provider.

            try
            {
                // The REST read request message for the getCFLicense() API call.
                InlineResponse200 result = apiInstance.GetCFLicense(sourcedId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefinitionsManagerApi.GetCFLicense: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sourcedId** | **string**| The GUID that identifies the Competency Framework License that is to be read from the service provider. | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

<a name="getcfsubject"></a>
# **GetCFSubject**
> InlineResponse200 GetCFSubject (string sourcedId)

The REST read request message for the getCFSubject() API call.

This is a request to the Service Provider to provide the specified Competency Framework Subject.  If the identified record cannot be found then the 'unknownobject' status code must be reported.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GetCFSubjectExample
    {
        public void main()
        {
            
            var apiInstance = new DefinitionsManagerApi();
            var sourcedId = sourcedId_example;  // string | The GUID that identifies the Competency Framework Subject that is to be read from the service provider.

            try
            {
                // The REST read request message for the getCFSubject() API call.
                InlineResponse200 result = apiInstance.GetCFSubject(sourcedId);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefinitionsManagerApi.GetCFSubject: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sourcedId** | **string**| The GUID that identifies the Competency Framework Subject that is to be read from the service provider. | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

